The orb strains against the chains as if it were alive. The crystals appear to be covering the chains.

Roll for arcana.

You see in the globe a fire elemental trying to escape it's bonds.

The crystals are creating an anomoly structure that seem to be containing and controlling it. All along the 

# Fire Elemental

*Legacy This doesn't reflect the latest rules and lore. Learn More*

**Armor Class** 13  
**Hit Points** 102 (12d10 + 36)  
**Speed** 50 ft.

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
| :------ | :------ | :------ | :------ | :------ | :------ |
| 10 (+0) | 17 (+3) | 16 (+3) | 6 (-2)  | 10 (+0) | 7 (-2)  |

**Damage Resistances** Bludgeoning, Piercing, and Slashing from Nonmagical Attacks  
**Damage Immunities** Fire, Poison  
**Senses** Darkvision 60 ft., Passive Perception 10  
**Languages** Ignan  
**Challenge** 5 (1,800 XP)  
**Proficiency Bonus** +3  

---

## Traits

**Fire Form.** The elemental can move through a space as narrow as 1 inch wide without squeezing. A creature that touches the elemental or hits it with a melee attack while within 5 feet of it takes 5 (1d10) fire damage. In addition, the elemental can enter a hostile creature's space and stop there. The first time it enters a creature's space on a turn, that creature takes 5 (1d10) fire damage and catches fire; until someone takes an action to douse the fire, the creature takes 5 (1d10) fire damage at the start of each of its turns.

**Illumination.** The elemental sheds bright light in a 30-foot radius and dim light in an additional 30 feet.

**Water Susceptibility.** For every 5 feet the elemental moves in water, or for every gallon of water splashed on it, it takes 1 cold damage.

---

## Actions

**Multiattack.** The elemental makes two touch attacks.

**Touch.** *Melee Weapon Attack:* +6 to hit, reach 5 ft., one target. *Hit:* 10 (2d6 + 3) fire damage. If the target is a creature or a flammable object, it ignites. Until a creature takes an action to douse the fire, the target takes 5 (1d10) fire damage at the start of each of its turns.

---

## Description

A faint humanoid shape shows in a fire elemental's capricious devastation. Wherever it moves, it sets its surroundings ablaze, turning the world to ash, smoke, and cinders.